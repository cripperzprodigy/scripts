# Ansible Role: Gitlab-CE



## Requirements

None.

## Role Variables



## Dependencies

None.

## Example Playbook

    - hosts: all
      roles:
        - ansible-gitlab


## License

MIT

## Author Information

Opsta (Thailand) Co.,Ltd.

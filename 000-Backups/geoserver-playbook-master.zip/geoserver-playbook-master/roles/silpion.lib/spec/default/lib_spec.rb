require 'spec_helper'

# write up RSpec integration tests here
#   see: http://serverspec.org/resource_types.html
